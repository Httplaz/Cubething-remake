#pragma once
#include "Chunk.h"
#include <random>
class WorldGenerator
{
public:
	static void fillChunk(Chunk* chunk);
private:
};

